main.c: The main program of spike detection
speedTest.c: A Script for testing the running speed of filtering, ASO, NEO and thresholing
dataPlot.py: Python program for thresholding result visuralisation

functions: Important functions include add noise, filtering, ASO, NEO and thresholding
utils: Some useful utils.